'use strict';
// Local-only launcher for the disposable Windows preview, not a production server.
const net = require('net');
const path = require('path');
const { spawn } = require('child_process');

const host = '127.0.0.1';
const port = 3296;
const origin = `http://${host}:${port}`;
const appDir = path.join(__dirname, 'app');
const probe = net.createServer();
probe.on('error', error => {
  console.error(`\nCannot start: ${host}:${port} is already in use or unavailable.`);
  console.error('Close any previous preview window, then try again.');
  console.error(error.message);
  process.exitCode = 1;
});
probe.listen(port, host, () => probe.close(() => {
  const env = { ...process.env,
    HOST: host, PORT: String(port), NODE_ENV: 'development',
    ENABLE_TEST_OTP: '1', ADMIN_PASSWORD: 'LocalTest2026'
  };
  // The preview must generate and reuse its own local keys, not pick up
  // unrelated settings from the host machine.
  for (const key of ['DATA_ENCRYPTION_KEY','WEB_PUSH_PUBLIC_KEY','WEB_PUSH_PRIVATE_KEY','WEB_PUSH_SUBJECT','TLS_KEY','TLS_CERT','CUSTOMER_PUBLIC_URL']) delete env[key];
  const child = spawn(process.execPath, [path.join(appDir, 'server.js')], {
    cwd: appDir, env, stdio: ['inherit', 'pipe', 'pipe'], windowsHide: true
  });
  let opened = false;
  let pending = '';
  child.stdout.on('data', chunk => {
    const text = chunk.toString('utf8');
    process.stdout.write(text);
    pending = (pending + text).slice(-4096);
    if (!opened && pending.includes('Rongyu customer and admin preview listening on')) {
      opened = true;
      console.log('\nCustomer: ' + origin + '/');
      console.log('Admin:    ' + origin + '/admin');
      console.log('Keep this window open. Close it when finished.\n');
      if (process.env.RY_NO_AUTOSTART !== '1' && process.platform === 'win32') {
        const browser = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', origin + '/'], {
          detached: true, stdio: 'ignore', windowsHide: true
        });
        browser.on('error', () => console.log('Open the Customer URL above in your browser.'));
        browser.unref();
      }
    }
  });
  child.stderr.on('data', chunk => process.stderr.write(chunk));
  child.on('error', error => { console.error('Could not start preview: ' + error.message); process.exitCode = 1; });
  child.on('exit', (code, signal) => {
    if (code && !signal) console.error('\nThe preview stopped with exit code ' + code + '.');
    process.exitCode = code || 0;
  });
  process.on('SIGINT', () => { try { child.kill(); } catch {} });
  process.on('SIGTERM', () => { try { child.kill(); } catch {} });
}));
