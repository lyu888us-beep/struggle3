@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Rongyu Local Preview - keep this window open
echo Starting a LOCAL TEST ONLY. No network tunnel is used.
echo Do not enter real identity or medical data.
echo.
if not exist "runtime\node.exe" (
  echo Missing runtime\node.exe. Extract the entire ZIP before starting.
  pause
  exit /b 1
)
"runtime\node.exe" "Launch.cjs"
echo.
echo The preview has stopped.
pause
