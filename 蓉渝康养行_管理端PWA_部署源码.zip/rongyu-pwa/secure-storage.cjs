'use strict';
// Server-side encryption protects sensitive database fields at rest. It does not
// replace server access control, OS encryption, backups, or an independent audit.
const crypto=require('crypto'),fs=require('fs'),path=require('path');
const TEXT_PREFIX='RYE1:',BLOB_PREFIX=Buffer.from('RYE1');
module.exports=function secureStorage(db,dataDir){
 db.exec('CREATE TABLE IF NOT EXISTS security_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
 const file=path.join(dataDir,'.data-encryption-key'),sentinel=db.prepare("SELECT value FROM security_settings WHERE key='keycheck'").get();
 let key;
 if(process.env.DATA_ENCRYPTION_KEY){
  const raw=process.env.DATA_ENCRYPTION_KEY.trim();
  key=/^[0-9a-fA-F]{64}$/.test(raw)?Buffer.from(raw,'hex'):Buffer.from(raw,'base64');
  if(key.length!==32)throw new Error('DATA_ENCRYPTION_KEY must contain exactly 32 bytes (hex or base64)');
 }else if(fs.existsSync(file)){
  key=Buffer.from(fs.readFileSync(file,'utf8').trim(),'base64');
  if(key.length!==32)throw new Error('Invalid data encryption key file');
 }else{
  if(sentinel)throw new Error('Data encryption key is missing; restore the original key before starting');
  key=crypto.randomBytes(32);
  try{fs.writeFileSync(file,key.toString('base64')+'\n',{mode:0o600,flag:'wx'})}catch(e){if(e.code!=='EEXIST')throw e;key=Buffer.from(fs.readFileSync(file,'utf8').trim(),'base64');if(key.length!==32)throw new Error('Invalid data encryption key file')}
 }
 function sealBytes(input){let iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv),body=Buffer.concat([cipher.update(Buffer.from(input)),cipher.final()]);return Buffer.concat([BLOB_PREFIX,iv,cipher.getAuthTag(),body])}
 function openBytes(value){let b=Buffer.from(value);if(!b.subarray(0,4).equals(BLOB_PREFIX))return b;if(b.length<32)throw new Error('Encrypted data is truncated');let decipher=crypto.createDecipheriv('aes-256-gcm',key,b.subarray(4,16));decipher.setAuthTag(b.subarray(16,32));return Buffer.concat([decipher.update(b.subarray(32)),decipher.final()])}
 function sealText(value){return TEXT_PREFIX+sealBytes(Buffer.from(String(value),'utf8')).subarray(4).toString('base64url')}
 function openText(value){let text=String(value??'');if(!text.startsWith(TEXT_PREFIX))return text;return openBytes(Buffer.concat([BLOB_PREFIX,Buffer.from(text.slice(TEXT_PREFIX.length),'base64url')])).toString('utf8')}
 if(sentinel){try{if(openText(sentinel.value)!=='rongyu-security-keycheck-v1')throw new Error('invalid')}catch{throw new Error('Data encryption key does not match this database')}}
 // Transactionally migrate existing test data without changing logical IDs or contents.
 db.transaction(()=>{
  if(!sentinel)db.prepare("INSERT INTO security_settings(key,value) VALUES('keycheck',?)").run(sealText('rongyu-security-keycheck-v1'));
  const updateItem=db.prepare('UPDATE items SET body=? WHERE id=?');
  for(const r of db.prepare('SELECT id,body FROM items').all())if(!r.body.startsWith(TEXT_PREFIX))updateItem.run(sealText(r.body),r.id);
  const updateUser=db.prepare('UPDATE users SET special=? WHERE id=?');
  for(const r of db.prepare('SELECT id,special FROM users').all())if(r.special&&!r.special.startsWith(TEXT_PREFIX))updateUser.run(sealText(r.special),r.id);
  const updateFile=db.prepare('UPDATE attachments SET name=?,bytes=? WHERE id=?');
  for(const {id} of db.prepare('SELECT id FROM attachments').all()){
   const r=db.prepare('SELECT id,name,bytes FROM attachments WHERE id=?').get(id);
   const name=r.name.startsWith(TEXT_PREFIX)?r.name:sealText(r.name),bytes=Buffer.from(r.bytes).subarray(0,4).equals(BLOB_PREFIX)?r.bytes:sealBytes(r.bytes);
   if(name!==r.name||bytes!==r.bytes)updateFile.run(name,bytes,r.id);
  }
 })();
 // A distinct derived key prevents sharing the AES key directly with HMAC.
 const lookupKey=Buffer.from(crypto.hkdfSync('sha256',key,Buffer.alloc(0),Buffer.from('rongyu-keyed-lookup-v1'),32));
 function lookup(domain,value){return crypto.createHmac('sha256',lookupKey).update(String(domain)+'\0'+String(value)).digest('hex')}
 return {sealText,openText,sealBytes,openBytes,lookup};
};
