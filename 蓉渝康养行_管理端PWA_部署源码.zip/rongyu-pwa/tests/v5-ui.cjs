'use strict';
// Run only against your own isolated test instance, not production data.
const {chromium,webkit,devices}=require('playwright');
const assert=require('assert'),fs=require('fs'),path=require('path');
const BASE=process.env.TEST_BASE||'https://127.0.0.1:3000';
const adminPassword=process.env.TEST_ADMIN_PASSWORD||fs.readFileSync(path.join(__dirname,'../data/.initial-admin-password'),'utf8').trim();
const chinese=['百会','合谷','内关','足三里','三阴交','印堂','神门','曲池','太冲','涌泉'];
const english=['Baihui','Hegu','Neiguan','Zusanli','Sanyinjiao','Yintang','Shenmen','Quchi','Taichong','Yongquan'];
const codes=['GV20','LI4','PC6','ST36','SP6','EX-HN3','HT7','LI11','LR3','KI1'];
async function noGenericNotice(p){
 assert.equal(await p.locator('.preview-notice').count(),0,'unexpected generic preview banner');
 const text=await p.locator('body').innerText();assert(!text.includes('测试版')&&!text.includes('试用版'),'generic version label is present');
}
async function noHorizontalOverflow(p){const sizes=await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));assert(sizes.scroll<=sizes.width+2,JSON.stringify(sizes));}
(async()=>{
 const browsers=[];let errors=[];
 try{
  const browser=await chromium.launch({args:['--ignore-certificate-errors']});browsers.push(browser);
  const desk=await browser.newContext({viewport:{width:1365,height:900},locale:'zh-CN',ignoreHTTPSErrors:true});
  const p=await desk.newPage();p.on('pageerror',e=>errors.push('desktop: '+e.message));
  await p.goto(BASE+'/tcm');await p.getByRole('heading',{name:'简单认识人体穴位'}).waitFor();
  assert.equal(await p.locator('#acupoints svg').count(),1);assert.equal(await p.locator('#acupoints .acupoint-card').count(),10);
  const pointsText=await p.locator('#acupoints').innerText();for(const name of chinese)assert(pointsText.includes(name),name);for(const code of codes)assert(pointsText.includes(code),code);
  assert(pointsText.includes('不要自行针刺')&&pointsText.includes('孕期')&&pointsText.includes('出血风险')&&pointsText.includes('现代医学'));
  assert.equal(await p.locator('#acupoints a[href^="https://www.nccih.nih.gov"]').count(),1);assert.equal(await p.locator('#acupoints a[href^="https://www.mskcc.org"]').count(),1);
  await noGenericNotice(p);await noHorizontalOverflow(p);console.log('PASS 十个穴位、原创示意图、知识介绍、安全提示、参考来源；公共页无通用版本横幅');
  await p.goto(BASE+'/login');await p.getByText('仅供演示，不是真实验证。').waitFor();await noGenericNotice(p);
  await p.getByRole('button',{name:'一键体验演示账号'}).click();await p.waitForURL('**/dashboard');await noGenericNotice(p);
  await p.goto(BASE+'/therapies');await p.getByRole('heading',{name:'简单认识人体穴位'}).waitFor();assert.equal(await p.locator('#acupoints .acupoint-card').count(),10);await noGenericNotice(p);
  await p.goto(BASE+'/sos');await p.getByText('此功能不会自动联系医院、管理人员或急救中心。').waitFor();await noGenericNotice(p);
  console.log('PASS 顾客登录、登录后穴位页和紧急求助提示；模拟认证限制未移除');
  const admin=await browser.newContext({viewport:{width:1365,height:900},locale:'zh-CN',ignoreHTTPSErrors:true}),a=await admin.newPage();a.on('pageerror',e=>errors.push('admin: '+e.message));
  await a.goto(BASE+'/admin');await a.getByRole('heading',{name:'管理端登录'}).waitFor();await noGenericNotice(a);
  await a.getByLabel('管理员账号（手机号或邮箱）').fill('admin@rongyu.local');await a.getByLabel('密码',{exact:true}).fill(adminPassword);await a.getByRole('button',{name:'登录管理端'}).click();await a.getByRole('heading',{name:'管理概览'}).waitFor();await noGenericNotice(a);
  console.log('PASS 管理端登录前后无通用版本横幅');
  const en=await browser.newContext({viewport:{width:1200,height:800},locale:'en-US',ignoreHTTPSErrors:true}),q=await en.newPage();q.on('pageerror',e=>errors.push('English: '+e.message));
  await q.goto(BASE+'/tcm');await q.getByRole('heading',{name:'An introduction to acupoints'}).waitFor({timeout:15000});
  await q.waitForFunction(()=>document.querySelector('#acupoints')?.innerText.includes('Acupoints: concepts and evidence'));
  const eText=await q.locator('#acupoints').innerText();for(const name of english)assert(eText.includes(name),name);assert(eText.includes('Do not needle yourself')&&eText.includes('pregnancy'));
  let remaining=await q.locator('#acupoints').evaluate(el=>[...el.querySelectorAll('p,h2,h3,h4,strong,small,span,text')].map(n=>n.textContent.trim()).filter(t=>/[\u3400-\u9fff]/.test(t)));
  assert.deepEqual(remaining,[],`untranslated acupoint text: ${JSON.stringify(remaining)}`);
  await q.locator('#ry-language-select').selectOption('zh');await q.getByRole('heading',{name:'简单认识人体穴位'}).waitFor();await q.locator('#ry-language-select').selectOption('en');await q.getByRole('heading',{name:'An introduction to acupoints'}).waitFor();
  console.log('PASS 英文十个穴位与科普、安全提示；语言手动切换');
  for(const [label,type,profile] of [['Android 模拟','chromium',devices['Pixel 7']],['iPhone 模拟','webkit',devices['iPhone 13']]]){
   let b=type==='webkit'?await webkit.launch():browser;if(type==='webkit')browsers.push(b);
   const ctx=await b.newContext({...profile,locale:'zh-CN',ignoreHTTPSErrors:true}),m=await ctx.newPage();m.on('pageerror',e=>errors.push(label+': '+e.message));
   await m.goto(BASE+'/tcm');await m.getByRole('heading',{name:'简单认识人体穴位'}).waitFor();await noHorizontalOverflow(m);await noGenericNotice(m);assert.equal(await m.locator('#acupoints .acupoint-card').count(),10);
   await m.goto(BASE+'/admin');await m.getByRole('heading',{name:'管理端登录'}).waitFor();await noHorizontalOverflow(m);await noGenericNotice(m);await ctx.close();console.log('PASS '+label+' 公共中医页、管理登录页排版与横幅');
  }
  const customer=await (await desk.request.get(BASE+'/manifest.webmanifest',{headers:{'Accept-Language':'zh-CN'}})).json(),management=await (await desk.request.get(BASE+'/admin.webmanifest',{headers:{'Accept-Language':'zh-CN'}})).json();
  assert.notEqual(customer.id,management.id);assert(customer.icons.length>=2&&management.icons.length>=2);assert(customer.start_url.startsWith('/')&&management.start_url.startsWith('/admin'));
  for(const icon of [customer.icons[0],management.icons[0]])assert.equal((await desk.request.get(BASE+icon.src)).status(),200);
  await p.goto(BASE+'/');await p.evaluate(()=>Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(Error('service worker not ready')),15000))]));
  await p.waitForFunction(()=>caches.keys().then(keys=>keys.some(k=>k.startsWith('rongyu-replica-v11'))),null,{timeout:10000});console.log('PASS 两端 PWA 清单、图标和 v11 service worker 缓存');
  assert.deepEqual(errors,[]);console.log('PASS 无浏览器脚本错误');
  await desk.close();await admin.close();await en.close();
 }finally{for(const b of browsers.reverse())await b.close().catch(()=>{})}
})().catch(e=>{console.error('V5 UI FAILED:',e.stack);process.exit(1)});
