'use strict';
const {chromium,request}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert'),Database=require('better-sqlite3');
const BASE=process.env.TEST_BASE||'https://127.0.0.1:3560',adminPassword=process.env.TEST_ADMIN_PASSWORD||fs.readFileSync(path.join(__dirname,'../data/.initial-admin-password'),'utf8').trim();
const account=`v3-${Date.now()}@example.test`,password='Password-Only-Test-2026',phone='000'+String(Date.now()).slice(-8),png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFElEQVR4nGMUbq9gwAaYsIoOWgkA2o8BIsAiYccAAAAASUVORK5CYII=','base64');
let users=[],steps=[];async function step(name,fn){await fn();steps.push(name);console.log('PASS',name)}
(async()=>{
 const b=await chromium.launch({args:['--ignore-certificate-errors']}),customer=await b.newContext({ignoreHTTPSErrors:true,locale:'zh-CN'}),admin=await b.newContext({ignoreHTTPSErrors:true,locale:'zh-CN'}),test=await b.newContext({ignoreHTTPSErrors:true,locale:'zh-CN'}),outsider=await b.newContext({ignoreHTTPSErrors:true,locale:'zh-CN'});let uid,record,token;
 try{
  let r=await admin.request.post(BASE+'/api/login',{data:{account:'admin@rongyu.local',password:adminPassword,admin:true}});assert.equal(r.status(),200);
  await step('注册生成稳定唯一档案号，长期安全 Cookie 和密码登录可用',async()=>{
   let r=await customer.request.post(BASE+'/api/register',{data:{name:'虚构身份V3',account,password,city:'测试城市V3'}});assert.equal(r.status(),201);let u=(await r.json()).user;uid=u.id;users.push(uid);assert.match(u.archiveNumber,/^RY-[A-F0-9]{20}$/);
   let ck=(await customer.cookies()).find(x=>x.name==='ry_session');assert(ck.secure&&ck.httpOnly&&ck.sameSite==='Lax');assert(ck.expires-Date.now()/1000>360*86400);token=ck.value;
   let me=(await (await customer.request.get(BASE+'/api/me')).json()).user;assert.equal(me.archiveNumber,u.archiveNumber);
   let other=await outsider.request.post(BASE+'/api/register',{data:{name:'另一虚构客户',account:`v3-other-${Date.now()}@example.test`,password}});assert.equal(other.status(),201);let v=(await other.json()).user;users.push(v.id);assert.notEqual(v.archiveNumber,u.archiveNumber);
   let state=await customer.storageState(),restored=await b.newContext({storageState:state,ignoreHTTPSErrors:true});assert.equal((await (await restored.request.get(BASE+'/api/me')).json()).user.id,uid);await restored.close();
  });
  await step('身份主表隔离加密，证件仅自愿文字，API 不返回完整号码',async()=>{
   let bad=await customer.request.patch(BASE+'/api/profile',{data:{name:'虚构身份V3',account,city:'测试城市V3',identityType:'passport',identityNumber:'TESTPASS12345',identityConsent:false,special:'虚构说明V3'}});assert.equal(bad.status(),400);
   let good=await customer.request.patch(BASE+'/api/profile',{data:{name:'虚构身份V3',account,city:'测试城市V3',identityType:'passport',identityNumber:'TESTPASS12345',identityConsent:true,special:'虚构说明V3'}});assert.equal(good.status(),200);let u=(await good.json()).user;assert.equal(u.identityMasked,'••••2345');assert(!JSON.stringify(u).includes('TESTPASS12345'));
   let db=new Database(path.join(__dirname,'../data/replica.sqlite'),{readonly:true}),base=db.prepare('SELECT name,account,city,special,identity_cipher FROM users WHERE id=?').get(uid),vault=db.prepare('SELECT profileCipher,accountIndex FROM user_identity_vault WHERE userId=?').get(uid);assert.equal(base.name,'');assert.equal(base.city,'');assert.equal(base.special,'');assert.equal(base.identity_cipher,null);assert(!JSON.stringify(base).includes(account));assert(vault.profileCipher.startsWith('RYE1:'));assert(!JSON.stringify(vault).includes('虚构说明V3'));assert(!JSON.stringify(vault).includes('TESTPASS12345'));db.close();
  });
  await step('测试验证码仅允许虚构身份、一次使用、不能登录普通账号或成为管理员',async()=>{
   assert.equal((await test.request.post(BASE+'/api/test-code/start',{data:{channel:'phone',identifier:'13900001111'}})).status(),400);assert.equal((await test.request.post(BASE+'/api/test-code/start',{data:{channel:'email',identifier:'real@example.com'}})).status(),400);
   let start=await test.request.post(BASE+'/api/test-code/start',{data:{channel:'phone',identifier:phone}});assert.equal(start.status(),200);let challenge=await start.json();assert(challenge.testOnly&&/^\d{6}$/.test(challenge.demoCode));assert.equal((await test.request.post(BASE+'/api/test-code/verify',{data:{challenge:challenge.challenge,code:'not-the-code'}})).status(),400);
   let ok=await test.request.post(BASE+'/api/test-code/verify',{data:{challenge:challenge.challenge,code:challenge.demoCode}});assert.equal(ok.status(),200);let data=await ok.json();users.push(data.user.id);assert(data.testOnly&&data.isNew&&data.user.testOtp&&data.user.role==='member');assert.equal((await test.request.post(BASE+'/api/test-code/verify',{data:{challenge:challenge.challenge,code:challenge.demoCode}})).status(),400);
   let promoted=await admin.request.patch(BASE+'/api/admin/users/'+data.user.id,{data:{role:'admin'}});assert.equal(promoted.status(),403);assert.equal((await test.request.get(BASE+'/api/admin/all')).status(),403);
   let again=await (await test.request.post(BASE+'/api/test-code/start',{data:{channel:'phone',identifier:phone}})).json();let same=await (await test.request.post(BASE+'/api/test-code/verify',{data:{challenge:again.challenge,code:again.demoCode}})).json();assert(!same.isNew);assert.equal(same.user.id,data.user.id);assert.equal(same.user.archiveNumber,data.user.archiveNumber);
  });
  await step('病情图片保留，证件类别、明显证件文件名和未确认图片被拒绝',async()=>{
   let bad=await customer.request.post(BASE+'/api/items/records',{data:{patientName:'虚构患者',category:'身份证照片',description:'虚构资料'}});assert.equal(bad.status(),400);
   let made=await customer.request.post(BASE+'/api/items/records',{data:{patientName:'虚构患者',category:'检查报告',description:'虚构测试病情'}});assert.equal(made.status(),201);record=(await made.json()).id;
   let no=await customer.request.post(BASE+'/api/records/'+record+'/attachments',{multipart:{file:{name:'medical.png',mimeType:'image/png',buffer:png}}});assert.equal(no.status(),400);
   let obvious=await customer.request.post(BASE+'/api/records/'+record+'/attachments',{multipart:{confirmNoIdPhoto:'true',file:{name:'passport.png',mimeType:'image/png',buffer:png}}});assert.equal(obvious.status(),400);
   let yes=await customer.request.post(BASE+'/api/records/'+record+'/attachments',{multipart:{confirmNoIdPhoto:'true',file:{name:'medical.png',mimeType:'image/png',buffer:png}}});assert.equal(yes.status(),201);let image=(await yes.json()).id;assert.equal((await outsider.request.get(BASE+'/api/attachments/'+image)).status(),404);assert.equal((await customer.request.get(BASE+'/api/attachments/'+image)).status(),200);
   let form=await customer.request.patch(BASE+'/api/profile',{multipart:{name:'虚构身份V3',account,identityPhoto:{name:'passport.png',mimeType:'image/png',buffer:png}}});assert(form.status()>=400);
  });
  await step('双端消息图片同样需要证件照片确认',async()=>{
   let no=await customer.request.post(BASE+'/api/messages',{multipart:{text:'仅测试',files:{name:'medical.png',mimeType:'image/png',buffer:png}}});assert.equal(no.status(),400);
   let obvious=await customer.request.post(BASE+'/api/messages',{multipart:{text:'仅测试',confirmNoIdPhoto:'true',files:{name:'passport.png',mimeType:'image/png',buffer:png}}});assert.equal(obvious.status(),400);
   let yes=await customer.request.post(BASE+'/api/messages',{multipart:{text:'仅测试',confirmNoIdPhoto:'true',files:{name:'medical.png',mimeType:'image/png',buffer:png}}});assert.equal(yes.status(),201);
   let thread=await (await admin.request.get(BASE+'/api/admin/messages/'+uid)).json();assert.equal(thread[0].senderName,'虚构身份V3');assert.equal(thread[0].attachments.length,1);
  });
  await step('主动退出后会话立即撤销，旧 Cookie 无法重用',async()=>{
   assert.equal((await customer.request.post(BASE+'/api/logout')).status(),200);assert.equal((await (await customer.request.get(BASE+'/api/me')).json()).user,null);
   let replay=await request.newContext({ignoreHTTPSErrors:true,extraHTTPHeaders:{cookie:'ry_session='+token}});let data=await (await replay.get(BASE+'/api/me')).json();assert.equal(data.user,null);await replay.dispose();
  });
 }finally{for(const id of users)await admin.request.delete(BASE+'/api/admin/users/'+id).catch(()=>{});await customer.close();await admin.close();await test.close();await outsider.close();await b.close()}
 console.log('V3 API tests:',steps.length,'passed');
})().catch(e=>{console.error('V3 API FAILED',e.stack);process.exit(1)});
