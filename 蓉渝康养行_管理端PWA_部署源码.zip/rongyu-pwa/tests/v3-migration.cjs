'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('assert'),Database=require('better-sqlite3');
const initSecure=require('../secure-storage.cjs'),initIdentities=require('../identity-store.cjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rongyu-migration-'));
try{
 const file=path.join(dir,'old.sqlite'),db=new Database(file);db.pragma('journal_mode=WAL');db.pragma('foreign_keys=ON');
 db.exec(`CREATE TABLE users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,account TEXT UNIQUE NOT NULL,city TEXT NOT NULL,age INTEGER,gender TEXT,special TEXT,salt TEXT,passhash TEXT,role TEXT,createdAt TEXT,identity_type TEXT,identity_cipher TEXT,identity_consent_at TEXT);
 CREATE TABLE items(id INTEGER PRIMARY KEY,userId INTEGER REFERENCES users(id),kind TEXT,body TEXT);
 CREATE TABLE attachments(id INTEGER PRIMARY KEY,name TEXT,bytes BLOB);`);
 db.prepare('INSERT INTO users VALUES(1,?,?,?,?,?,?,?,?,?,?,?,?,?)').run('虚构迁移客户','legacy-example@example.test','虚构城市',35,'女','虚构健康说明','salt1','hash1','member','2025-01-01','passport',null,'2025-01-02');
 db.prepare('INSERT INTO items VALUES(1,1,?,?)').run('records',JSON.stringify({description:'虚构病情内容'}));
 const secure=initSecure(db,dir);db.prepare('UPDATE users SET identity_cipher=? WHERE id=1').run(secure.sealText('TESTPASS12345'));
 const ids=initIdentities(db,secure);assert.equal(ids.migrate(),1);assert.equal(ids.migrate(),0);
 const original=ids.findByAccount('LEGACY-EXAMPLE@example.test');assert.equal(original.name,'虚构迁移客户');assert.equal(original.city,'虚构城市');assert.equal(original.special,'虚构健康说明');assert.equal(secure.openText(original.identity_cipher),'TESTPASS12345');assert.match(original.archiveNumber,/^RY-[A-F0-9]{20}$/);assert.equal(original.passhash,'hash1');
 const main=db.prepare('SELECT * FROM users WHERE id=1').get();assert.equal(main.name,'');assert.equal(main.city,'');assert.equal(main.special,'');assert.equal(main.identity_cipher,null);assert(!main.account.includes('legacy-example'));
 const profile=db.prepare('SELECT * FROM user_identity_vault WHERE userId=1').get();assert(profile.profileCipher.startsWith('RYE1:'));assert(!profile.profileCipher.includes('虚构'));assert.match(profile.accountIndex,/^[a-f0-9]{64}$/);
 const row=db.prepare('SELECT * FROM items WHERE id=1').get();assert.equal(row.userId,1);assert.equal(JSON.parse(secure.openText(row.body)).description,'虚构病情内容');
 for(const suffix of ['', '-wal'])if(fs.existsSync(file+suffix)){const raw=fs.readFileSync(file+suffix);for(const secret of ['legacy-example@example.test','虚构迁移客户','虚构健康说明','TESTPASS12345','虚构病情内容'])assert(!raw.includes(Buffer.from(secret)),`raw file leaked ${secret}`)}
 console.log('PASS 旧账号和业务记录迁移、身份加密隔离、原始数据页清除、档案号和幂等性');db.close();
}finally{fs.rmSync(dir,{recursive:true,force:true})}
